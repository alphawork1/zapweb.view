﻿yum.define([

], function () {

    Class('Unidade.Tipo').Static({
        ZAP: 0,
        CENTRAL: 1,
        COS: 2,
        TODOS: 3
    });

});